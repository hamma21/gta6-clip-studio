---
title: GTA 6 AI Clip Studio
emoji: 🎬
colorFrom: purple
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
---

# GTA 6 AI Clip Studio
AI viral-moment finder and clipper for YouTube VODs and uploads.

Optional env vars: `APP_PASSWORD`, `MAX_VIDEO_MIN` (default 240), `MAX_PARALLEL_JOBS` (default 2),
`FILE_TTL_MIN` (default 60), `YT_COOKIES_FILE`.
